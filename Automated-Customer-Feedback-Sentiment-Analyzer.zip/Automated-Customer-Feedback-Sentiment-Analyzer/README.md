# Automated-Customer-Feedback-Sentiment-Analyzer

**What this does**
- Reads `feedbacks.csv` (single column header `Feedback`) placed in the project folder.
- Runs a simple keyword-based sentiment analyzer (counts positive/negative keywords).
- Produces `feedbacks_with_sentiment.csv` with columns: `Feedback,Sentiment,Score`.

**How to run**
1. Place `feedbacks.csv` (example provided) in the project folder.
2. Open this folder in **UiPath Studio** (recommended 2020.10 — 2023+ should work).
3. Open `Main.xaml` and run the project.
4. Result file `feedbacks_with_sentiment.csv` will be created in the same folder.

**Notes**
- This is a self-contained, dependency-free implementation that uses an `Invoke Code` (VB.NET) block inside `Main.xaml`.
- The sentiment analyzer is rule-based (keyword lists). For production / better accuracy, integrate a 3rd-party NLP API or use ML packages.
- If UiPath complains about XAML compatibility, open `Main.xaml`, replace the Invoke Code with the VB code found in `invokecode-vb.txt` inside an `Invoke Code` activity manually.
